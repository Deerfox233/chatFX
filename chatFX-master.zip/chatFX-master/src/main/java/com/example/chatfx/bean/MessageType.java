package com.example.chatfx.bean;

public class MessageType {
    public static int COMMON = 0;
    public static int DISCONNECTION = 5;
}
