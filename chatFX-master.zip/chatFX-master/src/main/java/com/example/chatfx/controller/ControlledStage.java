package com.example.chatfx.controller;

import com.example.chatfx.StageController;

public interface ControlledStage {
    void setStageController(StageController stageController);
}
