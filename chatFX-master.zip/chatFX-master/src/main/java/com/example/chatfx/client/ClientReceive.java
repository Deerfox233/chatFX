package com.example.chatfx.client;

public class ClientReceive {
}
